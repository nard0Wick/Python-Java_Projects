//function getData(){ 
//    /*let div = document.getElementById("dv1"); 
//    let x = div.getAttribute("guid"); */
//    alert($(".nav-bar input[name='guid']").val());
//}  


/*var charcs = [];
var ids;

function setData() {
    var charcs = [];
    ids = [];
    var checkBox = document.getElementsByName("check");
    for (var check of checkBox) {
        if (check.checked) {
            ids.push(check.value);
        }
    }
    alert(ids);
    console.log(ids);

    ids.forEach(element => {
        charcs.push({
            src: document.getElementById(element).getElementsByTagName("img")[0].src,
            nombre: document.getElementById(element).getElementsByTagName("h4")[0].textContent,
            desc: document.getElementById(element).getElementsByTagName("p")[0].textContent

        });
    });

    localStorage.setItem("charcs", JSON.stringify(charcs));

}*/

//setData();

(function () {
    var state;
    var charcs; 

    window.addEventListener('load', function () {
        state = JSON.parse(localStorage['stateSt'] || '{}');

        for (var i in state) {
            //console.log(i)
            var ch = document.querySelector('div.card input[name="' + i + '"]');
            if (ch) ch.checked = true;
        }

        var allChecked = document.getElementsByClassName('save-state');

        for (var i = 0; i < allChecked.length; i++) {
            allChecked[i].addEventListener('click', function (evt) {
                if (this.checked) {
                    state[this.name] = true;

                } else if (state[this.name]) {
                    delete state[this.name];
                }

                localStorage.stateSt = JSON.stringify(state);  
                //update page
                location.reload();
            });
        }

        //localStorage.state = JSON.stringify(state);

        charcs = []; 
        console.log("here",JSON.parse(this.localStorage['stateSt']));
        for(var i in JSON.parse(this.localStorage['stateSt'])){ 
            var value = document.querySelector('div.card input[name="'+i+'"]').value;  

            console.log(value); 

            charcs.push({
                src: document.getElementById(value).getElementsByTagName("img")[0].src,
                nombre: document.getElementById(value).getElementsByTagName("h4")[0].textContent,
                desc: document.getElementById(value).getElementsByTagName("p")[0].textContent,
                precio: document.getElementById(value).getElementsByTagName("h5")[0].textContent
            });

        }  
        console.log("charcs",charcs);
        localStorage.setItem("charcs", JSON.stringify(charcs));
    }); 
    
})();

/*(function () {
    var state;

    window.addEventListener('load', function () {
        state = JSON.parse(localStorage['stateSt'] || '{}');

        for (var i in state) {
            console.log(i)
            var ch = document.querySelector('div.card input[name="' + i + '"]');
            if (ch) ch.checked = true;
        }

        var allChecked = document.getElementsByClassName('save-state');

        for (var i = 0; i < allChecked.length; i++) {
            allChecked[i].addEventListener('click', function (evt) {
                if (this.checked) {
                    state[this.name] = true;

                } else if (state[this.name]) {
                    delete state[this.name];
                }

                localStorage.stateSt = JSON.stringify(state);
            });
        }

        //localStorage.state = JSON.stringify(state);

        console.log(state);
    });

})();*/
/** 
 * for more context: https://www.marcorpsa.com/ee/t2641.html
 */


/*var div = document.getElementById("card"); 
   var src = div.getElementsByTagName("img")[0].src;  
   var lb = div.getElementsByTagName("p")[0];
   alert(src); 

   var image = document.createElement("img"); 
   image.src = src; 

   document.body.appendChild(img);*/


/*function getData(){ 
    var charcs = localStorage.getItem("charcs"); 
    localStorage.clear(); 

    charcs.forEach(element =>{ 
        var div = document.createElement("div");
        div.className = "shopCard";  

        var nombre = document.createElement('h4'); 
        nombre.textContent = element.nombre; 

        div.appendChild(nombre); 

        document.body.appendChild(div);

    });
}*/