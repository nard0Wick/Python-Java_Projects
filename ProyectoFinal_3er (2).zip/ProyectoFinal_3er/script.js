let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length-1) {slideIndex = 0}
  slides[slideIndex].style.display = "block";
  setTimeout(showSlides, 4000); // Change image every 2 seconds
}

//next,previous controls 
function plus(n){ 
  show(slideIndex += n);
} 

function show(n){ 
  let slides = document.getElementsByClassName("mySlides"); 
  //console.log(slides); 
  if(n > slides.length-1){slideIndex = 0} 
  if(n < 0){slideIndex = slides.length -1} 
  for(i = 0; i < slides.length; i++){ 
    slides[i].style.display = "none";
  }
  slides[slideIndex].style.display = "block";
}

/*let slideIndex = 0;
showSlides(); 

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 3000); // Change image every 2 seconds
} 

function plus(){ 

}*/




