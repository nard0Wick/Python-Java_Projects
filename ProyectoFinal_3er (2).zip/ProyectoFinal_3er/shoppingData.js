function getData(){ 
    /*let div = document.getElementById("dv1"); 
    let x = div.getAttribute("guid"); */
    alert($(".nav-bar input[name='guid']").val());
}